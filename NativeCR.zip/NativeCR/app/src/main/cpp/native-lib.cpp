#include <jni.h>
#include <string>
#include <fstream>
#include <iostream>

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_nativecr_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string title = "Android GPT";
    return env->NewStringUTF(title.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
    Java_com_example_nativecr_MainActivity_process(
        JNIEnv* env,
        jobject mainActivityInstance /* this */) {
    jclass mainActivityCls = env ->GetObjectClass(mainActivityInstance);
    const jmethodID jmethodId = env ->GetMethodID(mainActivityCls,"processInJava","()Ljava/lang/String;");

    if (jmethodId == nullptr){
        return env -> NewStringUTF("");
    }
    const jobject result = env->CallObjectMethod(mainActivityInstance, jmethodId);
    const std::string java_msg = env->GetStringUTFChars((jstring) result, JNI_FALSE);
    const std::string c_msg = "Result from java => ";
    const std::string msg = c_msg + java_msg;
    return env ->NewStringUTF(msg.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_nativecr_MainActivity_ai1(
        JNIEnv* env,
        jobject /* this */
        ,int x
) {
    // will output [11.0, 13.0, 17.0] as little endian
    std::ofstream out;
    out.open("bin.dat", std::ios::out | std::ios::binary);
    float f = 11.0;
    out.write(reinterpret_cast<const char*>(&f), sizeof(float));
    f = 13.0;
    out.write(reinterpret_cast<const char*>(&f), sizeof(float));
    f = 17.0;
    out.write(reinterpret_cast<const char*>(&f), sizeof(float));
    out.close();
    std::string c_msg = std::to_string(x);
    return env->NewStringUTF(c_msg.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_nativecr_MainActivity_ai2(
        JNIEnv* env,
        jobject /* this */) {
    std::string c_msg = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum!";
    return env->NewStringUTF(c_msg.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_nativecr_MainActivity_ai3(
        JNIEnv* env,
        jobject /* this */) {
    std::string c_msg = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum!";
    return env->NewStringUTF(c_msg.c_str());
}