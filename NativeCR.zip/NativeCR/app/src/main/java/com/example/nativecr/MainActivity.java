package com.example.nativecr;

import android.os.Bundle;

import android.text.method.ScrollingMovementMethod;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.view.View;
import android.widget.TextView;
import com.example.nativecr.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'nativecr' library on application startup.
    static {
        System.loadLibrary("nativecr");
    }

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.response.setMovementMethod(new ScrollingMovementMethod());
        binding.response2.setMovementMethod(new ScrollingMovementMethod());
        binding.response3.setMovementMethod(new ScrollingMovementMethod());
        int y = 3121;
        // Show title
        TextView tv = binding.sampleText;
        tv.setText(stringFromJNI());
        // User answers 1st question
        binding.button.setOnClickListener(view -> {
            binding.button.setText(R.string.answerButton);
            binding.response.setBackgroundColor(ContextCompat.getColor(this,R.color.responseColor));
            if (binding.question1.getText().toString().contains("good"))
                binding.response.setText(ai1(y));
            else
                binding.response.setText(" l");
        });
        // User answers 2nd question
        binding.button2.setOnClickListener(view -> {
            binding.button2.setText(R.string.answerButton);
            binding.response2.setBackgroundColor(ContextCompat.getColor(this,R.color.responseColor));
            if (binding.question2.getText().toString().contains("UNO"))
                binding.response2.setText(ai2());
            else
                binding.response2.setText(" l");

        });
        // User answers 3rd question
        binding.button3.setOnClickListener(view -> {
            binding.button3.setText(R.string.answerButton);
            binding.response3.setBackgroundColor(ContextCompat.getColor(this,R.color.responseColor));
            if (binding.question3.getText().toString().contains("yes"))
                binding.response3.setText(ai3());
            else
                binding.response3.setText(" a");
        });

    }

    public String processInJava(){
        return "Processed in Java";
    }

    public native String process();
    /**
     * A native method that is implemented by the 'nativecr' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
    public native String ai1(int some);
    public native String ai2();
    public native String ai3();

}